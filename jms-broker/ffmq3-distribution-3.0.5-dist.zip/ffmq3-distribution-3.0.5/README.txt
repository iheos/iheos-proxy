FFMQ is released under the GNU LGPL license, in order to allow integration in all kind of software.
See the included COPYING.LESSER file for details.

Also see the included documentation in the docs/ directory